package com.company.dao;

public class DAOExeption extends Exception{
    public DAOExeption(String mensaje){
        super(mensaje);
    }
}
