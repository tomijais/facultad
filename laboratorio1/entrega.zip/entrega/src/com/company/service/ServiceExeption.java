package com.company.service;

public class ServiceExeption extends Exception{
    public ServiceExeption(String mensaje){
        super(mensaje);
    }
}
