package com.company.gui;

import com.company.entidades.Usuario;
import com.company.service.ServiceExeption;
import com.company.service.ServiceUsuario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {

    public static void main(String[] args) throws ServiceExeption {
        PanelManager panel = new PanelManager(); //Crea la GUI

    }
}