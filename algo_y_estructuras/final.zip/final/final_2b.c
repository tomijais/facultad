#include <stdio.h>
#include <stdlib.h>

int main()

{
    // texto caracter a caracter

    
    return 0;
}